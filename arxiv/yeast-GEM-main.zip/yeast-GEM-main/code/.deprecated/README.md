## Deprecated Scripts

Scripts that either:

* Include changes that were already integrated to the model and will not be needed anymore.
* Were deprecated by newer functions.
