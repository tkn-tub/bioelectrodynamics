## Missing fields

Various scripts for adding and curating various annotation fields to the model, that are useful for model curation. These functions should be written in a generic format, so that they could be reused for future curations.
