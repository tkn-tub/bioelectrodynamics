## Physiology

Data on yeast growth under different conditions, biomass composition, gene essentiality experiments, etc.

Data files that are only used once, for instance containing a list of new reactions to be added to the model, should instead be stored in a dedicated folder in ../modelCuration.
