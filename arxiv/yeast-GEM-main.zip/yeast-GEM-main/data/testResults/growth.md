## R2 of growth rate prediction
0.8798

![Growth curve](growth.png)
