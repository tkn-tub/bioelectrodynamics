## Databases

Yeast data from different databases (KEGG, SGD, swissprot, etc), or other data that could be repeatedly used.

Data files that are only used once, for instance containing a list of new reactions to be added to the model, should instead be stored in a dedicated folder in ../modelCuration.
